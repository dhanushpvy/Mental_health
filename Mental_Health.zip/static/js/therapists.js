document.addEventListener('DOMContentLoaded', function () {
  const therapistData = [
    {
      name: "Dr.Dharan",
      city: "Chennai",
      specialty: "Anxiety & Stress",
      experience: 10,
      rating: 4.8,
      available: true,
      phone: "6381650069",
      email: "dhanushkumaranpvy4921@gmail.com"
    },
    {
      name: "Mr.Daniel",
      city: "Madurai",
      specialty: "Depression & Mood Disorders",
      experience: 8,
      rating: 4.6,
      available: false,
      phone: "9715681106",
      email: "danielglad2004@gmail.com"
    },
    {
      name: "Dr.Dharshini",
      city: "Coimbatore",
      specialty: "Child & Adolescent Therapy",
      experience: 12,
      rating: 4.9,
      available: true,
      phone: "9790294248",
      email: "tkdharshini205@gmail.com"
    },
    {
      name: "Dr.Dhivya",
      city: "Coimbatore",
      specialty: "Stress Management",
      experience: 12,
      rating: 4.9,
      available: true,
      phone: "8526366761",
      email: "sdhivya2004@gmail.com"
    }
  ];

  const searchInput = document.getElementById("searchInput");
  const cityFilter = document.getElementById("cityFilter");
  const sortBy = document.getElementById("sortBy");
  const searchBtn = document.getElementById("searchBtn");
  const therapistList = document.getElementById("therapistList");

  function renderTherapists(data) {
    therapistList.innerHTML = "";

    if (data.length === 0) {
      therapistList.innerHTML = "<p>No therapists found.</p>";
      return;
    }
    data.forEach(t => {
      const card = document.createElement("div");
      card.classList.add("therapist-card");
      card.innerHTML = `
        <h3>${t.name}</h3>
        <p><strong>City:</strong> ${t.city}</p>
        <p><strong>Specialty:</strong> ${t.specialty}</p>
        <p><strong>Experience:</strong> ${t.experience} years</p>
        <p><strong>Rating:</strong> ⭐ ${t.rating}</p>
        <p><strong>Availability:</strong> ${t.available ? "<span class='online'>Online</span>" : "<span class='offline'>Offline</span>"}</p>
        <p><strong>email:</strong> ${t.email}</p>
        <p>📞 ${t.phone}</p>
      `;
      // 📅 Book Appointment Button
      const bookBtn = document.createElement("button");
      bookBtn.innerText = "📅 Book Appointment";
      bookBtn.className = "book-btn";
      bookBtn.addEventListener("click", () => bookAppointment(t));
      card.appendChild(bookBtn);

      // 📞 Call Button
      const callBtn = document.createElement("button");
      callBtn.innerText = "📞 Call";
      callBtn.className = "book-btn";
      callBtn.style.marginLeft = "10px";
      callBtn.addEventListener("click", () => {
       window.location.href = `tel:${t.phone}`;
      });
      card.appendChild(callBtn);

      therapistList.appendChild(card);
    });
  }
  function bookAppointment(therapist) {

  const message = `Hello ${therapist.name}, I would like to book an appointment regarding ${therapist.specialty}. Please let me know your available time.`;

  // Remove non-digit characters and add country code
  const phone = therapist.phone.replace(/\D/g, ''); // Only digits

  const whatsappURL = `https://wa.me/91${phone}?text=${encodeURIComponent(message)}`

  window.open(whatsappURL, "_blank");

}


  function filterAndSortTherapists() {
    const searchVal = searchInput.value.toLowerCase();
    const cityVal = cityFilter.value;
    const sortVal = sortBy.value;

    let filtered = therapistData.filter(t =>
      (t.name.toLowerCase().includes(searchVal) || t.specialty.toLowerCase().includes(searchVal)) &&
      (cityVal === "" || t.city === cityVal)
    );

    if (sortVal === "name") {
      filtered.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortVal === "experience") {
      filtered.sort((a, b) => b.experience - a.experience);
    }

    renderTherapists(filtered);
  }

  searchBtn.addEventListener("click", filterAndSortTherapists);
  renderTherapists(therapistData); // initial load
});
