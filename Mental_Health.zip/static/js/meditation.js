const quotes = [
    "Close your eyes and breathe...",
    "Let your thoughts come and go.",
    "Feel your body relax.",
    "You're safe and calm.",
    "Let go of any tension.",
    "Be here. Be now."
];

let countdown;
let quoteTimer;
let timeLeft = 0;
let isPaused = false;
let quoteIndex = 0;

function startMeditation() {
    const duration = parseInt(document.getElementById("duration").value);
    timeLeft = duration;
    isPaused = false;
    quoteIndex = 1;

    document.getElementById("startBtn").style.display = "none";
    document.getElementById("pauseBtn").style.display = "inline";
    document.getElementById("resumeBtn").style.display = "none";
    document.getElementById("stopBtn").style.display = "inline";

    const quoteEl = document.getElementById("quote");
    quoteEl.textContent = quotes[0];
    document.getElementById("timer").textContent = formatTime(timeLeft);

    clearInterval(countdown);
    clearInterval(quoteTimer);

    quoteTimer = setInterval(updateQuote, 10000);
    countdown = setInterval(updateTimer, 1000);
}

function updateTimer() {
    if (!isPaused && timeLeft > 0) {
        timeLeft--;
        document.getElementById("timer").textContent = formatTime(timeLeft);

        if (timeLeft <= 0) {
            stopMeditation();
            document.getElementById("quote").textContent = "Meditation Complete ✨";
        }
    }
}

function updateQuote() {
    if (!isPaused) {
        const quoteEl = document.getElementById("quote");
        quoteEl.classList.remove("fade-in");
        void quoteEl.offsetWidth;
        quoteEl.classList.add("fade-in");
        quoteEl.textContent = quotes[quoteIndex % quotes.length];
        quoteIndex++;
    }
}

function pauseMeditation() {
    isPaused = true;
    document.getElementById("pauseBtn").style.display = "none";
    document.getElementById("resumeBtn").style.display = "inline";
}

function resumeMeditation() {
    isPaused = false;
    document.getElementById("pauseBtn").style.display = "inline";
    document.getElementById("resumeBtn").style.display = "none";
}

function stopMeditation() {
    clearInterval(countdown);
    clearInterval(quoteTimer);
    isPaused = false;
    timeLeft = 0;
    document.getElementById("quote").textContent = "Click Start to begin";
    document.getElementById("timer").textContent = "";
    
    document.getElementById("startBtn").style.display = "inline";
    document.getElementById("pauseBtn").style.display = "none";
    document.getElementById("resumeBtn").style.display = "none";
    document.getElementById("stopBtn").style.display = "none";
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
}
