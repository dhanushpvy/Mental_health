// Replace with your Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyBRfkx2MwFUmaKasVC-SGXTbljJLpSlznY",
  authDomain: "login.firebaseapp.com",
  projectId: "login-78f51",
  storageBucket: "login.appspot.com",
  messagingSenderId: "818295034181",
  appId: "1:818295034181:web:ac422ad074c93f8e70ee2c"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
