let breathInterval = null;
let timerInterval = null;
let remainingSeconds = 0;
let isPaused = false;

function startBreathing() {
  const minutes = parseInt(document.getElementById("duration").value);
  remainingSeconds = minutes * 60;

  document.getElementById("startBtn").style.display = "none";
  document.getElementById("pauseBtn").style.display = "inline-block";
  document.getElementById("stopBtn").style.display = "inline-block";
  document.getElementById("resumeBtn").style.display = "none";

  isPaused = false;
  animateBreathing();
  breathInterval = setInterval(animateBreathing, 8000);
  updateTimer();
}

function animateBreathing() {
  if (isPaused) return;

  const circle = document.getElementById("circle");
  const text = document.getElementById("breath-text");

  text.textContent = "Breathe In...";
  circle.style.transform = "scale(1.5)";

  setTimeout(() => {
    if (!isPaused) {
      text.textContent = "Breathe Out...";
      circle.style.transform = "scale(1)";
    }
  }, 4000);
}

function updateTimer() {
  const timer = document.getElementById("timer");

  timerInterval = setInterval(() => {
    if (!isPaused && remainingSeconds > 0) {
      remainingSeconds--;
      const min = String(Math.floor(remainingSeconds / 60)).padStart(2, '0');
      const sec = String(remainingSeconds % 60).padStart(2, '0');
      timer.textContent = `${min}:${sec}`;
    }

    if (remainingSeconds <= 0) {
      stopBreathing();
      document.getElementById("breath-text").textContent = "Session Completed!";
    }
  }, 1000);
}

function pauseBreathing() {
  isPaused = true;
  document.getElementById("pauseBtn").style.display = "none";
  document.getElementById("resumeBtn").style.display = "inline-block";
  document.getElementById("breath-text").textContent = "Paused...";
}

function resumeBreathing() {
  isPaused = false;
  document.getElementById("resumeBtn").style.display = "none";
  document.getElementById("pauseBtn").style.display = "inline-block";
  document.getElementById("breath-text").textContent = "Resuming...";
  animateBreathing();
}

function stopBreathing() {
  clearInterval(breathInterval);
  clearInterval(timerInterval);
  remainingSeconds = 0;
  isPaused = false;

  document.getElementById("timer").textContent = "00:00";
  document.getElementById("breath-text").textContent = "Session Stopped.";

  document.getElementById("startBtn").style.display = "inline-block";
  document.getElementById("pauseBtn").style.display = "none";
  document.getElementById("resumeBtn").style.display = "none";
  document.getElementById("stopBtn").style.display = "none";

  document.getElementById("circle").style.transform = "scale(1)";
}
