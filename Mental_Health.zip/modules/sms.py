# modules/sms.py
from twilio.rest import Client

# Replace these with your real Twilio credentials
TWILIO_ACCOUNT_SID = 'your_account_sid'
TWILIO_AUTH_TOKEN = 'your_auth_token'
TWILIO_PHONE_NUMBER = '+1234567890'  # Your Twilio phone number

client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

def send_sms(to_number, therapist_name, user_name="User"):
    message_body = f"Hi {therapist_name}, you have a new appointment request from {user_name} via the Mental Wellness App."

    message = client.messages.create(
        body=message_body,
        from_=TWILIO_PHONE_NUMBER,
        to=to_number
    )
    return message.sid
